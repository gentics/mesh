import { Component } from '@angular/core';

@Component({
  selector: 'demo-welcome-screen',
  templateUrl: './welcome-screen.component.html',
  styleUrls: ['./welcome-screen.component.css']
})
export class WelcomeScreenComponent { }
